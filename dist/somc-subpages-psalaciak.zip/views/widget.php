<section class="somc-subpages">
    
    <h2><?php echo $view['title'] ?></h2>

    <div>
        <?php self::viewListSubpages($view['post_id'], $view['items']); ?>
    </div>
</section>